## ELENCO PARAMETRI
-baseurl            = URL BASE                                   default = https://external-gw-staging.easyparksystem.net/api/
-call               = Chiamata da effettuare                     default = permit_get
-refreshtoken       = Token auth di EasyPark                     default = f9d290c93e9906f297528dec6edf64b9bfce7a4ba63c2ea4a47062dcb5de9bda
-parameters         = Parametri URL                              default = 
-requestbodypath    = Path file da dove leggere la request body  default = requestbody.txt
-responsepath       = Path file dove scrivere la risposta        default = response.txt

## UTILIZZO
- modifica il file "requestparams.txt" con i parametri della richiesta e "requestbody.txt" con la richiesta da inviare in caso di chiamata POST
- da cmd esegui l'exe con i relativi parametri 

Considera per gli esempi come valori fissi:
-baseurl=https://external-gw-staging.easyparksystem.net/api/
-redfreshtoken=f9d290c93e9906f297528dec6edf64b9bfce7a4ba63c2ea4a47062dcb5de9bda
-requestbodypath = "requestbody.txt"
-responsepath = "response.txt"

## Esempi risposte:
    - permit_create
    - Nel file -requestbodypath indicare la lista di permessi da creare:
        - [{"carLicenceNumber":"CP269AW",
            "discountRate":0,
            "maxDiscount":null,
            "parkingareaNumbers":[{"areaCountryCode":"IT",
            "areaNo":22137}],
            "permitAreaName":"Zona 1 Agevolazione",
            "permitIdentifier":"USE_CARLICENCENUMBER",
            "permitName":"ROSA",
            "permitNote":null,
            "phoneNumber":null,
            "priceExclVat":null,
            "priceNotSubjectToVat":null,
            "priceTotal":0.0,
            "priceVat":null,
            "remainingParkingMinutes":null,
            "validFrom":"2022-01-28T00:00:00",
            "validTo":"2022-03-31T00:00:00",
            "visibleForEnforcement":false},
        {"carLicenceNumber":"FF550VH",
            "discountRate":0,
            "maxDiscount":null,
            "parkingareaNumbers":[{"areaCountryCode":"IT",
            "areaNo":22137}],
            "permitAreaName":"Zona 1 Agevolazione",
            "permitIdentifier":"USE_CARLICENCENUMBER",
            "permitName":"ROSA",
            "permitNote":null,
            "phoneNumber":null,
            "priceExclVat":null,
            "priceNotSubjectToVat":null,
            "priceTotal":0.0,
            "priceVat":null,
            "remainingParkingMinutes":null,
            "validFrom":"2022-10-05T00:00:00",
            "validTo":"2022-12-31T00:00:00",
            "visibleForEnforcement":false}]
        - EasyParkService.exe -call=permit_create
- "permit_get"
    - EasyParkService.exe -call=permit_get -parameters={\"permitUniqueId\":\"7099b33e-be98-4246-bb40-dad80e73952c\"}
- "permit_findallareas"
    - EasyParkService.exe -call=permit_findallareas
- "permit_batch_delete"
    - Nel file -requestbodypath indicare la lista di id da eliminare:
        - [
            {"applicationUniqueId":"IDPROVA1"},
            {"applicationUniqueId":"IDPROVA2"},
            {"applicationUniqueId":"IDPROVA3"}
          ]
    - EasyParkService.exe -call=permit_batch_delete

## Esempi risposte:
    - permit_get
        - [{"code": "200", "codedescription": "OK", "content": , "error": }]
        - [{"code": "200", "codedescription": "OK", "content": {"permitName":"ROSA","permitAreaName":"Zona 1 Agevolazione","parkingareaNo":22137,"countryCode":"IT","discountRate":0.0000000000,"maxDiscount":null,"remainingParkingMinutes":null,"visibleForEnforcement":false,"carLicenceNumber":"TESTF55","phoneNumber":null,"permitIdentifier":"USE_CARLICENCENUMBER","validFrom":"2023-05-01T00:00:00.570+0000","validTo":"2023-05-30T23:59:59.570+0000","priceTotal":0.00,"priceExclVat":null,"priceNotSubjectToVat":null,"priceVat":null,"permitNote":null,"uniqueId":"f2906f52-30af-4f95-82d0-95b3f91b1582"}, error: }]
        - [{"code": 404, "codedescription": "Not Found", "content": , "error": {"timestamp":"2023-05-18T14:23:57.130+0000","status":404,"error":"Not  Found","message":"No message available","path":"/api/permit/"}}]
    - permit_create (a buon fine)
        - [{"code":200,"codedescription":"OK","content":"[{\"permitName\":\"ROSA\",\"permitAreaName\":\"Zona 1 Agevolazione\",\"parkingareaNo\":22137,\"countryCode\":\"IT\",\"discountRate\":0,\"maxDiscount\":0,\"remainingParkingMinutes\":0,\"visibleForEnforcement\":false,\"carLicenceNumber\":\"FF550VH\",\"phoneNumber\":\"\",\"permitIdentifier\":\"USE_CARLICENCENUMBER\",\"validFrom\":\"2022-10-05T00:00:00.000+0000\",\"validTo\":\"2022-12-31T00:00:00.000+0000\",\"priceTotal\":0,\"priceExclVat\":0,\"priceNotSubjectToVat\":0,\"priceVat\":0,\"permitNote\":\"\",\"uniqueId\":\"164075c8-884a-4d7e-ae20-55505deefed7\"}]","error":""},{"code":200,"codedescription":"OK","content":"[{\"permitName\":\"ROSA\",\"permitAreaName\":\"Zona 1 Agevolazione\",\"parkingareaNo\":22137,\"countryCode\":\"IT\",\"discountRate\":0,\"maxDiscount\":0,\"remainingParkingMinutes\":0,\"visibleForEnforcement\":false,\"carLicenceNumber\":\"DP239AG\",\"phoneNumber\":\"\",\"permitIdentifier\":\"USE_CARLICENCENUMBER\",\"validFrom\":\"2022-01-01T00:00:00.000+0000\",\"validTo\":\"2022-12-31T00:00:00.000+0000\",\"priceTotal\":0,\"priceExclVat\":0,\"priceNotSubjectToVat\":0,\"priceVat\":0,\"permitNote\":\"\",\"uniqueId\":\"55853601-e510-48e1-b00b-d1e89a71e0c9\"}]","error":""}]
## ELENCO CALL IMPLEMENTATE
- "permit_create"
- "permit_get"
- "permit_findallareas"
- "permit_batch_delete"

## Documentazione

URL: https://external-gw-staging.easyparksystem.net/api/swagger-ui.html#/authentication-resource/getJwtUsingPOST

RefreshToken: f9d290c93e9906f297528dec6edf64b9bfce7a4ba63c2ea4a47062dcb5de9bda

Codice area: 22137